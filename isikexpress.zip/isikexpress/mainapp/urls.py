from django.urls import path
from . import views

urlpatterns = [
    path('',views.visitorhomepage), #  '' şeklindeki anasayfa visitor için , register olduktan sonra farklı olabilir
    path('register/',views.register),
    path('login/',views.login)

]