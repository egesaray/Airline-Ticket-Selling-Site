from django.shortcuts import render
from django.http import HttpResponse
from .models import *  # importing databases

# Create your views here.

def visitorhomepage(request):
    #database ile etkileşime geçeceğimiz zaman burda yapacağız ve return içinde göndereceğiz
    return render(request,'mainapp/visitorhomepage.html')

def register(request):

    return render(request,'mainapp/register.html')

def login(request):

    return render(request,'mainapp/login.html')