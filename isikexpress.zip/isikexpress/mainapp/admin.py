from django.contrib import admin

# Register your models here.

from .models import *

#admin sayfasından db yönetebilmek için kullanılacak syntax=   admin.site.register(tablename)